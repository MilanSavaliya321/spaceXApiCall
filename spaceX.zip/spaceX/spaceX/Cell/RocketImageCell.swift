//
//  RocketImageCell.swift
//  spaceX
//
//  Created by Milan on 08/10/22.
//

import UIKit

class RocketImageCell: UICollectionViewCell {
    
    @IBOutlet weak var imgRocket: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

}
